import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./AuthForm.css";

export default function AuthForm({ mode }) {
  const navigate = useNavigate();
  const isSignIn = mode === "signin";

  const title = useMemo(() => {
    if (mode === "signin") return "Sign in to your account";
    if (mode === "signup") return "Sign up an account";
    if (mode === "update") return "Update password";
    return "Auth";
  }, [mode]);

  const [email, setEmail] = useState("you@example.com");
  const [password, setPassword] = useState("12345678");
  const [showPw, setShowPw] = useState(false);

  // 你原来的登录逻辑可以放这里；我先给最小可运行跳转
  const loginAsUser = () => navigate("/products");
  const loginAsManager = () => navigate("/add-product");

  return (
    <div className="page auth-page">
      <div className="card auth-card">
        <h1 className="auth-title">{title}</h1>

        <div className="auth-form">
          <div className="auth-field">
            <div className="auth-label">Email</div>
            <input
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="auth-field">
            <div className="auth-label">Password</div>

            <div className="auth-pw-row">
              <input
                className="input"
                type={showPw ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                className="btn"
                onClick={() => setShowPw((s) => !s)}
              >
                {showPw ? "Hide" : "Show"}
              </button>
            </div>
          </div>

          {isSignIn ? (
            <div className="auth-btn-row">
              <button className="btn btn-primary auth-primary" onClick={loginAsUser}>
                Login as User
              </button>
              <button className="btn btn-primary auth-primary" onClick={loginAsManager}>
                Login as Manager
              </button>

              <div className="auth-bottom">
                <span>
                  Don’t have an account?{" "}
                  <Link className="auth-link" to="/signup">Sign up</Link>
                </span>
                <Link className="auth-link" to="/update-password">Forgot password?</Link>
              </div>
            </div>
          ) : (
            <button className="btn btn-primary auth-primary">
              {mode === "signup" ? "Sign up" : "Update"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
