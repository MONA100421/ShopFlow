import AuthForm from "../components/AuthForm";

export default function SignUp() {
  return <AuthForm mode="signup" />;
}
