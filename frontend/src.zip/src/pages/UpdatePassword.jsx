import AuthForm from "../components/AuthForm";

export default function UpdatePassword() {
  return <AuthForm mode="update" />;
}
