import AuthForm from "../components/AuthForm";

export default function SignIn() {
  return <AuthForm mode="signin" />;
}
